<?php

namespace Source;

/**
 * Class Autoloader
 *
 * @package Source
 */
class Autoloader {
    static public function loader($className) {
        $filename = str_replace('\\', '/', $className) . ".php";
        if (file_exists($filename)) {
            include($filename);
            if (class_exists($className)) {
                return TRUE;
            }
        }

        return FALSE;
    }
}

spl_autoload_register('Source\Autoloader::loader');