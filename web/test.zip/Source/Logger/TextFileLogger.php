<?php

namespace Source\Logger;


class TextFileLogger extends AbstractLogger
{
    private $filePath;

    public function __construct($filePath)
    {
        $this->filePath = $filePath;
    }

    /**
     * Write log to the file
     */
    private function writeLog($message)
    {
        $fp = fopen($this->filePath, 'a+');

        if (!$fp) {
            throw new \Exception("Could not create log file.");
        }

        $data = $message.PHP_EOL;
        fwrite($fp, $data);
        fclose($fp);
    }

    public function log($level, $message, array $context = [])
    {
        // This method should call other methods based on $level value.
        $date = new \DateTime();

        $this->writeLog(sprintf('[%s] %s: %s', $date->format('y-m-d H:i:s'), $level, $message));
    }

}