<?php
/**
 * Created by PhpStorm.
 * User: synthetic
 * Date: 08.07.16
 * Time: 9:45
 */

namespace Source\EntityManager;


use Source\Entity\InventoryItem;

class EntityFactory
{
    function makeEntity($entityName)
    {
        if ($entityName == 'InventoryItem')
        {
            return $this->makeInventoryEntity();
        }

        throw new \Exception('Wrong entity name');
    }

    private function makeInventoryEntity()
    {
        return new InventoryItem();
    }
}