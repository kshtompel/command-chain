<?php

namespace Source\EntityManager;

use Source\DataStore\DataStore;


/**
 * Class AbstractEntityManager.
 *
 * Implements SplSubject interface.
 */
abstract class AbstractEntityManager implements \SplSubject
{
    protected $_entities = array();

    protected $_entityIdToPrimary = array();

    protected $_entityPrimaryToId = array();

    protected $_entitySaveList = array();

    protected $_nextId = null;

    protected $_dataStore = null;

    /**
     * @var EntityFactory
     */
    protected $factory;

    /**
     * @var \SplObjectStorage;
     */
    protected $storage;

    /**
     * AbstractEntityManager constructor.
     *
     * @param \SplObjectStorage $storage
     * @param EntityFactory $factory
     */
    function __construct(\SplObjectStorage $storage, EntityFactory $factory)
    {
        $this->storage = $storage;
        $this->factory = $factory;
    }

    /**
     * @param \SplObserver $observer
     */
    public function attach(\SplObserver $observer)
    {
        $this->storage->attach($observer);
    }

    /**
     * @param \SplObserver $observer
     */
    public function detach(\SplObserver $observer)
    {
        $this->storage->detach($observer);
    }

    /**
     * @param null $newData
     */
    public function notify($newData = null)
    {
        foreach ($this->storage as $obj) {
            $obj->update($this, $newData);
        }
    }

}
