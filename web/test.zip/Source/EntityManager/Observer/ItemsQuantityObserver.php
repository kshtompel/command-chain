<?php

namespace Source\EntityManager\Observer;

/**
 * Class ItemsQuantityObserver
 *
 * Observe EntityManager update
 */
class ItemsQuantityObserver implements \SplObserver
{
    public function update(\SplSubject $subject, array $data = null)
    {
        if (isset($data['qoh']) && $data['qoh'] < 5) {
            $message = "Item SKU: $data[sku], QoH: $data[qoh]";

            $sent = mail('someperson@example.com', 'Quantity of item changed', $message);
        }
    }

}