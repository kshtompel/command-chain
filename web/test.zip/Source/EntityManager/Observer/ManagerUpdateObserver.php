<?php

namespace Source\EntityManager\Observer;

use Source\Logger\LoggerInterface;
use Source\Logger\LogLevel;


/**
 * Class ManagerUpdateObserve
 *
 * Observe EntityManager update
 */
class ManagerUpdateObserver implements \SplObserver
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    public function update(\SplSubject $subject, array $updateData = null)
    {
        $this->logger->log(LogLevel::INFO, print_r($updateData, true));
    }

}